2 layers (1-oz copper), 1.6 mm (0.062") thickness, LPI green soldermask and white silkscreen both sides, lead-free HASL plating on pads
Overall dimensions 65 x 51 mm (2.559" x 2.008")
All copper layers positive
Min. trace/spacing 0.2 mm (0.008")
Min. hole size 0.3 mm (0.012")

*-F_Cu.gtl: Top copper
*-B_Cu.gbl: Bottom copper
*-F_Mask.gts: Top soldermask
*-B_Mask.gbs: Bottom soldermask
*-F_SilkS.gto: Top silkscreen
*-B_SilkS.gbo: Bottom silkscreen
*-Edge_Cuts.gm1: Outline
*-PTH.drl: Drill file (plated holes)
*-NPTH.drl: Drill file (non-plated holes)